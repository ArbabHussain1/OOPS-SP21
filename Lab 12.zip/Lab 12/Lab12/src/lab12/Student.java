package lab12;
import java.util.Scanner;
public class Student extends Person implements Association
{
    Scanner input = new Scanner(System.in);
    private int rollNo;
    private int semester;

    public Student(String name, String id) 
    {
        super(name, id);
        this.rollNo = rollNo;
        this.semester = semester;
    }
    
    public void Associate()
    {
        System.out.print("Enter your rollNo: ");
        rollNo = input.nextInt();
        System.out.print("Enter your semester: ");
        semester = input.nextInt();
    }

    @Override
    public String toString() 
    {
        return "STUDENT" + "\n" + super.toString() + "\nrollNo = " + rollNo + "\nsemester = " + semester;
    }
}
