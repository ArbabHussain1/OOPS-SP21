package lab12;

public class HumanResource<T>
{
    private T[] array;

    public HumanResource() 
    {
    }
    
    public void add(T p)
    {
        if(array == null)
        {
            array = (T[])new Object[1];
            array[0] = p;
            if(p instanceof Association)
                ((Association)p).Associate();
        }
        else
        {
            extend();
            array[array.length-1] = p;
            if(p instanceof Association)
                ((Association)p).Associate();
        }
    }
    
    private void extend()
    {
        T[] temp = array;
        array = (T[])new Object[temp.length + 1];
        for(int i = 0; i < array.length - 1; i++)
        {
            array[i] = temp[i];
        }
    }
    
    public void delete(T p)
    {
        T[] temp =  array;
        array = (T[])new Object[temp.length - 1];
        for(int i = 0, j = 0; i < array.length; i++)
        {
            if(p.equals(temp[j]))
            {
                j++;
            }
            array[i] = temp[j];
            j++;
        }
    }
    
//    private Association[] array;
//
//    public HumanResource() 
//    {
//    }
//    
//    public void add(Association p)
//    {
//        if(array == null)
//        {
//            array = new Association[1];
//            array[0] = p;
//            p.Associate();
//        }
//        else
//        {
//            extend();
//            array[array.length-1] = p;
//            p.Associate();
//        }
//    }
//    
//    private void extend()
//    {
//        Association[] temp = array;
//        array = new Association[temp.length + 1];
//        for(int i = 0; i < array.length - 1; i++)
//        {
//            array[i] = temp[i];
//        }
//    }
//    
//    public void delete(Association p)
//    {
//        Association[] temp =  array;
//        array = new Association[temp.length - 1];
//        for(int i = 0, j = 0; i < array.length; i++)
//        {
//            if(p.equals(temp[j]))
//            {
//                j++;
//            }
//            array[i] = temp[j];
//            j++;
//        }
//    }
//    
//    public void display()
//    {
//        for(int i=0; i<array.length; i++)
//        {
//            System.out.println(array[i] + "\n");
//        }
//    }
    
    
    @Override
    public String toString()
    {
        String str = "\n";
        for(int i = 0; i < array.length; i++)
        {
            str += array[i] + "\n\n";
        }
        return str;
    }
}
