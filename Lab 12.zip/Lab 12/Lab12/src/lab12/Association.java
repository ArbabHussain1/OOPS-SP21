package lab12;

public interface Association 
{
    public void Associate();
}
