package lab12;

public class Runner 
{
    public static void main(String[] args) 
    {
        HumanResource h = new HumanResource();
        Association T = new Teacher("Ali Raza", "T00121");
        Association S = new Student("M.Farhan", "S0639");
        
        h.add(T);
        h.add(123);
        h.add(S);
        h.add(new Student("Saif Ali", "S0788"));
        h.add("STRING");
        
        h.delete(T);
        
        System.out.println(h);        
    } 
}
