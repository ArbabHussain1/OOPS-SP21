package lab12;
public class Person 
{
    protected String name;
    protected String id;

    public Person() 
    {
        this.name = null;
        this.id = null;
    }

    public Person(String name, String id) 
    {
        this.name = name;
        this.id = id;
    } 

    @Override
    public String toString() 
    {
        return "Name = " + name + "\nId = " + id;
    }
}
