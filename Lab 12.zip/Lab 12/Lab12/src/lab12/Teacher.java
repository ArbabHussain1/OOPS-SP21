package lab12;
import java.util.Scanner;
public class Teacher extends Person implements Association
{
    Scanner input = new Scanner(System.in);
    private String designation;
    private String department;

    public Teacher(String name, String id) 
    {
        super(name, id);
    }
    
    public void Associate()
    {
        System.out.print("Enter your designation: ");
        designation = input.nextLine();
        System.out.print("Enter your department: ");
        department = input.nextLine(); 
    }

    @Override
    public String toString() 
    {
        return "TEACHER" + "\n" + super.toString() + "\ndesignation = " + designation + "\ndepartment = " + department;
    }
}
